from distutils.core import setup
setup(name='geneanalysis_project',
      version='1.0',
      packages=['cache', 'docs', 'modules', 'text']
      )
